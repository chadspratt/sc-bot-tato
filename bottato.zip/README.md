A Starcraft II bot with an emphasis on moving in formation
